import streamlit as st
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split

def main():
    
    st.title('Health Genie - Disease Prediction')

    # Load the dataset for symptoms
    symptoms_data = pd.read_csv('C:/Users/ASUS Vivobook/Downloads/archive (1)/Testing.csv')

    # Select first 15 symptoms
    selected_features = symptoms_data.columns[1:21]

    # Separate features (X) and target (y)
    X = symptoms_data[selected_features]
    y = symptoms_data['prognosis']

    # Load the dataset for diseases and descriptions
    diseases_data = pd.read_csv('C:/Users/ASUS Vivobook/Downloads/archive (3)/symptom_Description.csv')

    # Create a dictionary mapping diseases to their descriptions
    disease_info = dict(zip(diseases_data['Disease'], diseases_data['Description']))
    
    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

    # Train Decision Tree classifier
    clf = DecisionTreeClassifier()
    clf.fit(X_train, y_train)

    # Get all symptom names
    symptom_names = X.columns.tolist()

    # Checkbox to select symptoms
    selected_symptoms = st.sidebar.multiselect("Select Symptoms", symptom_names)

    # Predict disease based on selected symptoms
    if st.sidebar.button('Predict'):
        st.write("Selected Symptoms:", selected_symptoms)  # Debugging line

        if len(selected_symptoms) > 0:
            # Create user data DataFrame with selected symptoms
            # Create user data DataFrame with selected symptoms
            user_data = pd.DataFrame({selected_symptoms: [1 if selected_symptom in selected_symptoms else 0 for selected_symptom in selected_features]}, index=[0])  # Initialize DataFrame with all feature columns

            st.write("User Data:", user_data)  # Debugging line

            # Predict disease
            disease_prediction = clf.predict(user_data)
            predicted_disease = disease_prediction[0]
            
            st.write(f'Predicted Disease: {predicted_disease}')

            # Display additional information about the predicted disease
            if predicted_disease in disease_info:
                st.write('Additional Information:')
                st.write(disease_info[predicted_disease])
            else:
                st.write('Additional information not available.')
        else:
            st.warning("Please select symptoms for prediction.")
        
        st.markdown("""
        **Disclaimer:** This is a machine learning-based model for disease prediction. While it can provide insights, it may not always be accurate. For accurate medical advice, please consult a qualified healthcare professional.
        """)

if __name__ == "__main__":
    main()
